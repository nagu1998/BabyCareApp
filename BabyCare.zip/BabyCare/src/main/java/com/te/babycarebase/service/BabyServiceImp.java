package com.te.babycarebase.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.te.babycarebase.dao.BabyDao;
import com.te.babycarebase.dto.BabyInfo;

@Service
public class BabyServiceImp implements BabyService {
	@Autowired
	BabyDao dao;
	@Override
	public BabyInfo search(int id) {
		if(id<=0) {
			return null;
		}
		else {
			return dao.search(id);
		}
	}
	@Override
	public boolean addData(BabyInfo babyInfo) {
		return dao.addData(babyInfo);
	}
	@Override
	public List<BabyInfo> getAll() {
		return dao.getAll();
	}
	@Override
	public boolean deleteData(int id) {
		 return dao.deleteData(id);
	}
	@Override
	public boolean updateData( int id,String name) {
		return dao.updateData(id,name);
	}
	@Override
	public boolean authenticate(String uname, String pwd) {
		
		return dao.authenticate(uname,pwd);
	}
}
