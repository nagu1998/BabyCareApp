package com.te.babycarebase.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.te.babycarebase.dto.BabyInfo;
@Repository
public class BabyDaoHibernate implements BabyDao {

	@Override
	public BabyInfo search(int id) {
		BabyInfo babyInfo = null;
		 try {
				EntityManagerFactory factory = Persistence.createEntityManagerFactory("ems");
				 EntityManager entityManager = factory.createEntityManager();
				 EntityTransaction entityTransaction = entityManager.getTransaction();
				 
				 entityTransaction.begin();
				 babyInfo =  entityManager.find(BabyInfo.class, id);
				 entityTransaction.commit();
				 return babyInfo;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 return babyInfo;
	}

	@Override
	public boolean addData(BabyInfo babyInfo) {
		boolean isAdded = false;
		 try {
			EntityManagerFactory factory = Persistence.createEntityManagerFactory("ems");
			 EntityManager entityManager = factory.createEntityManager();
			 EntityTransaction entityTransaction = entityManager.getTransaction();
			 
			 entityTransaction.begin();
			 entityManager.persist(babyInfo);
			 entityTransaction.commit();
			 isAdded = true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		return isAdded;
	}

	@Override
	public List<BabyInfo> getAll() {
		List<BabyInfo> list = null;
		try {
			EntityManagerFactory factory = Persistence.createEntityManagerFactory("ems");
			 EntityManager entityManager = factory.createEntityManager();
			 EntityTransaction entityTransaction = entityManager.getTransaction();
			 
			 Query query = entityManager.createQuery("From BabyInfo");
			 list =  query.getResultList();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public boolean deleteData(int id) {
		boolean isDeleted = false;
		try {
			EntityManagerFactory factory = Persistence.createEntityManagerFactory("ems");
			 EntityManager entityManager = factory.createEntityManager();
			 EntityTransaction entityTransaction = entityManager.getTransaction();
			 
			 entityTransaction.begin();
			 BabyInfo babyInfo =  entityManager.find(BabyInfo.class, id);
			 entityManager.remove(babyInfo);
			 entityTransaction.commit();
			 isDeleted = true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return isDeleted;
	}

	@Override
	public boolean updateData(int id,String name) {
		boolean isUpdated = false;
		try {
			EntityManagerFactory factory = Persistence.createEntityManagerFactory("ems");
			 EntityManager entityManager = factory.createEntityManager();
			 EntityTransaction entityTransaction = entityManager.getTransaction();
			 
			 entityTransaction.begin();
			 BabyInfo babyInfo =  entityManager.find(BabyInfo.class, id);
			 if(babyInfo != null) {
				 if(babyInfo.getName().equals(name)) {
					 isUpdated = false;
				 }else {
				 babyInfo.setName(name);
				 isUpdated = true;
				 }
			 }
			 entityTransaction.commit();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return isUpdated;
	}

	@Override
	public boolean authenticate(String uname, String pwd) {
		boolean valid = false;
		try {
			EntityManagerFactory factory = Persistence.createEntityManagerFactory("ems");
			 EntityManager entityManager = factory.createEntityManager();
			 EntityTransaction entityTransaction = entityManager.getTransaction();
			 
			Query query = entityManager.createQuery("From BabyInfo where uname =:uname and pwd =:pwd");
			query.setParameter("uname", uname);
			query.setParameter("pwd",pwd);
			BabyInfo info =  (BabyInfo) query.getSingleResult();
			if(info != null) {
				valid = true;
			}else {
				valid = false;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return valid;
	}

}
