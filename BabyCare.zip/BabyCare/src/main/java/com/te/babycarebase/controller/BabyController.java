package com.te.babycarebase.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.SessionAttribute;

import com.te.babycarebase.dto.BabyInfo;
import com.te.babycarebase.service.BabyService;
import com.te.babycarebase.service.BabyServiceImp;

@Controller
public class BabyController {
	@Autowired
	BabyService service;
	// BabyInfo info;

	@GetMapping("/login")
	public String loginPage() {
		return "LoginPage";
	}

	@PostMapping("/login")
	public String authenticate(ModelMap map, String uname, String pwd, HttpServletRequest req) {
		boolean valid = service.authenticate(uname, pwd);
		if (valid == true) {
			HttpSession mySession = req.getSession();
			mySession.setAttribute("loggedIn", uname);
			mySession.setMaxInactiveInterval(30);
			return "SearchPage";
		} else {
			map.addAttribute("errMsg", "Invalid Id or Password");
			return "LoginPage";
		}
	}

	@GetMapping("/SearchPage")
	public String searchPage(@SessionAttribute(name = "loggedIn", required = false) String uname, ModelMap map) {
		if (uname != null) {
			return "SearchPage";
		} else {
			map.addAttribute("errMsg", "Invalid Access.. Please Login First");
			return "forward:login";
		}
	}

	@PostMapping("/search")
	public String search(ModelMap map, BabyInfo info,
			@SessionAttribute(name = "loggedIn", required = false) String uname) {
		if (uname != null) {
			BabyInfo babyInfo = service.search(info.getId());
			if (babyInfo != null) {
				map.addAttribute("babyObj", babyInfo);
				return "SearchResult";
			} else {
				map.addAttribute("errMsg", "Invalid Credintials Or Id Might not be Present");
				return "Invalid";
			}
		} else {
			map.addAttribute("errMsg", "Invalid Session or Invalid Access ..Please Login First");
			return "forward:login";
		}
	}

	@GetMapping("/InsertPage")
	public String insertPage(@SessionAttribute(name = "loggedIn", required = false) String uname,ModelMap map) {
		if(uname != null) {
		return "InsertPage";
		}else {
			map.addAttribute("errMsg", "Invalid Access.. Please Login First");
			return "forward:login";
		}
	}

	@PostMapping("/insert")
	public String addData(ModelMap map, BabyInfo info,
			@SessionAttribute(name = "loggedIn", required = false) String uname) {
		if (uname != null) {
			boolean isInserted = service.addData(info);
			if (isInserted == true) {
				map.addAttribute("babyObj", "Inserted Successfully");
				return "InsertResult";
			} else {
				map.addAttribute("errMsg", "Insertion Failed...!!!!\nPlease Try With Different Id");
				return "Invalid";
			}
		} else {
			map.addAttribute("errMsg", "Invalid Session or Invalid Access ..Please Login First");
			return "forward:login";
		}
	}

	@GetMapping("/displayAll")
	public String getAll(ModelMap map, @SessionAttribute(name = "loggedIn", required = false) String uname) {
		if (uname != null) {
			List<BabyInfo> list = service.getAll();
			if (list != null) {
				map.addAttribute("all", list);
				return "AllBabies";
			} else {
				map.addAttribute("errMsg", "No Babies Found in The Database.!!");
				return "Invalid";
			}
		} else {
			map.addAttribute("errMsg", "Invalid Session or Invalid Access ..Please Login First");
			return "forward:login";
		}
	}

	@GetMapping("/Delete")
	public String deletePage(@SessionAttribute(name = "loggedIn", required = false) String uname,ModelMap map) {
		if(uname != null) {
		return "DeleteAccount";
		}else{
			map.addAttribute("errMsg", "Invalid Access.. Please Login First");
			return "forward:login";
		}
	}

	@PostMapping("/delete")
	public String deleteData(ModelMap map, int id,
			@SessionAttribute(name = "loggedIn", required = false) String uname) {
		if (uname != null) {
			boolean isDeleted = service.deleteData(id);
			if (isDeleted == true) {
				map.addAttribute("babyObj", "Deleted Successfully");
				return "DeleteResult";
			} else {
				map.addAttribute("errMsg", "Entered Id is Not Found..!!!\\nPlease Try With Different Id");
				return "Invalid";
			}
		} else {
			map.addAttribute("errMsg", "Invalid Session or Invalid Access ..Please Login First");
			return "forward:login";
		}

	}

	@GetMapping("/update")
	public String upadtePage(@SessionAttribute(name = "loggedIn", required = false) String uname,ModelMap map) {
		if(uname != null) {
		return "Update";
		}else {
			map.addAttribute("errMsg", "Invalid Access.. Please Login First");
			return "forward:login";
		}
	}

	@PostMapping("/update")
	public String updateData(ModelMap map, int id, String name,
			@SessionAttribute(name = "loggedIn", required = false) String uname) {
		if (uname != null) {
			boolean isUpdated = service.updateData(id, name);
			if (isUpdated == true) {
				map.addAttribute("babyObj", "Updated Successfully");
				return "UpdateResult";
			} else {
				map.addAttribute("errMsg", "Entered Name is As That of the old Name...\n Choose different Name");
				return "Invalid";
			}
		} else {
			map.addAttribute("errMsg", "Invalid Session or Invalid Access ..Please Login First");
			return "forward:login";
		}
	}

	@GetMapping("/contact")
	public String contactPage() {
		return "redirect:https://www.instagram.com/nagaraj_athani_26/";
	}

	@GetMapping("/logout")
	public String logout(HttpServletRequest req, ModelMap map, HttpSession httpSession) {
		httpSession.invalidate();
		map.addAttribute("errMsg", "Logged Out Successfully");
		return "forward:login";
	}
}
