package com.te.babycarebase.service;

import java.util.List;

import com.te.babycarebase.dto.BabyInfo;

public interface BabyService {
	public BabyInfo search(int id);
	public boolean addData(BabyInfo babyInfo);
	public List<BabyInfo> getAll();
	public boolean deleteData(int id);
	public boolean updateData(int id,String name);
	public boolean authenticate(String uname, String pwd);
}
